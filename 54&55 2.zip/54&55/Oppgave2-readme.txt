Kjøring av kode: 
1. Åpne koden i VSCode og start terminalen.
2. Kjør kommandoen npm install for å installere nødvendige pakker.
   - Om du fortsatt opplever feil etter installasjon kan du trykke:
     command + shift + P og velg Reload Window i VsCode. 

3. For å kjøre appen: 
   - iOS: Kjør npm run ios 
   - Web: Trykk w i terminalen
   - Android: Trykk a i terminalen
   Husk: For Android-testing trenger du enten en fysisk Android-enhet 
   eller en emulator, som kan startes via Android Studio. 

---

Funksjoner: 
- Laste opp bilder/kunstverk fra kamera eller bildegalleri
- Legge til beskrivelse og hashtags på posten
- Navigasjon til Hjem-skjerm og Kart nederst i TabNavigation
- Et bildegalleri med liste over kunstverk
- Mulighet til å like kunstverk i bildegalleriet
- Navigasjon fra bildegalleri til detaljer ved å klikke på kunstverk
- Mulighet til å kommentere kunstverk på side for detaljer
- Navigasjon fra bildegalleri til artistens profil ved å klikke på brukernavn over posten
- Sanntidsdatabase i Firebase som umiddelbart registrerer nye likes, kommentarer og poster. 

---

Kjente problemer:
- Forsinkelser i lasting av bilder
- Forsinkelse i opplastning av bilder
- Lokasjon ikke tilgjengelig på web
- Lokasjon er tilgjengelig på Android etter bruker har godtatt tilgang

---

Testet på: 
- iOS simulator - iOS 18.0:
Enhet: iPhone 16 Pro
Enhet: iPhone SE (3rd generation)

- Android emulator - Android 14.0:
Enhet: Pixel 3a

- Web: 
Google chrome nettleser

---